function pheromoneLevel = InitializePheromoneLevels(numberOfCities, tau0)
    pheromoneLevel = tau0*ones(numberOfCities,numberOfCities);
end